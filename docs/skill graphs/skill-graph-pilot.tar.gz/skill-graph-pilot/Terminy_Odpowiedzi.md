# Terminy Odpowiedzi na Wniosek (Art. 7)

---
description: "Określenie terminów odpowiedzi na wniosek pracownika o informacje dotyczące wynagrodzeń oraz konsekwencje ich przekroczenia."
related: ["00_INDEX_Art7", "Procedura_Wniosku", "Kary_za_Opoznienie"]
topic: "Terminy procesowania wniosków o transparentność"
---

## Podstawa Prawna

**Art. 7 ust. 1 Dyrektywy UE 2023/970:**
> "Informacje te są udzielane **w rozsądnym terminie** w odpowiedzi na wniosek pracownika."

**Precyzacja (Motyw 23 Dyrektywy):**
> Rozsądny termin nie powinien przekraczać **dwóch miesięcy** od daty złożenia wniosku.

---

## Termin Standardowy

### 2 miesiące (max)

**Liczenie terminu:**
- **Dzień 0:** Data otrzymania wniosku (email = data wysłania)
- **Dzień 60:** Ostatni dzień na odpowiedź

**Przykład:**
- Wniosek: 15 stycznia 2026
- Termin odpowiedzi: **najpóźniej 15 marca 2026**

**Uwaga:** Jeśli ostatni dzień przypada na weekend/święto → **pierwszy dzień roboczy po tym terminie**.

---

## Terminy Skrócone (Best Practice)

Choć Dyrektywa dopuszcza 2 miesiące, **zalecamy krótsze terminy** aby uniknąć eskalacji:

| Sytuacja | Zalecany Termin |
|----------|-----------------|
| **Prosty wniosek** (dane dostępne w systemie) | **7-14 dni** |
| **Skomplikowany wniosek** (wymaga obliczeń EVG) | **30 dni** |
| **Wniosek precedensowy** (pierwszy w firmie) | **45 dni** |

**Dlaczego skrócone?**
- Buduje zaufanie pracownika
- Redukuje ryzyko skargi do PIP
- Pokazuje compliance culture

---

## Konsekwencje Opóźnienia

### Dla Pracodawcy

**Brak odpowiedzi w terminie:**
1. ⚠️ **Skarga do PIP** — pracownik może zgłosić naruszenie
2. ⚠️ **Kara finansowa** — do ustalenia przez państwa członkowskie (Polska: regulacje w trakcie implementacji)
3. ⚠️ **Odwrócenie ciężaru dowodu** — jeśli pracownik pójdzie do sądu o dyskryminację, pracodawca musi udowodnić brak dyskryminacji (Art. 18 Dyrektywy)

**Przykład sankcji (możliwe kierunki w Polsce):**
- Pierwsza skarga: Ostrzeżenie PIP
- Ponowne naruszenie: Kara do 30,000 PLN
- Uporczywe naruszenia: Zakaz działalności (w skrajnych przypadkach)

### Dla Pracownika

**Jeśli pracodawca nie odpowie:**
1. ✅ **PIP:** Złóż skargę do Państwowej Inspekcji Pracy
2. ✅ **Sąd:** Wnieś powództwo o dyskryminację płacową (odwrócony ciężar dowodu działa na Twoją korzyść)
3. ✅ **Media:** Publicznie ujawnić brak transparentności (zgodnie z Art. 11 Dyrektywy — ochrona sygnalistów)

---

## Przedłużenie Terminu (Kiedy Możliwe?)

**Pracodawca może przedłużyć termin TYLKO jeśli:**
1. Poinformuje pracownika **w ciągu 30 dni** o przedłużeniu
2. Poda uzasadnienie (np. "Wymaga to obliczeń EVG dla 500 pracowników")
3. Maksymalne przedłużenie: **30 dni** (łącznie 90 dni)

**Przykład komunikacji:**

```
Od: HR Department
Do: Jan Kowalski
Data: 10 lutego 2026

Temat: Przedłużenie terminu odpowiedzi (Art. 7)

Szanowny Panie Kowalski,

Otrzymaliśmy Pana wniosek z dnia 15 stycznia 2026. 

Z uwagi na konieczność przeprowadzenia wartościowania stanowisk dla 500 pracowników 
(metoda EVG zgodnie z Art. 4 Dyrektywy), prosimy o przedłużenie terminu odpowiedzi 
o 30 dni (do 15 kwietnia 2026).

Zobowiązujemy się dostarczyć pełną odpowiedź w tym terminie.

Z poważaniem,
[HR Manager]
```

---

## Monitorowanie Terminów (Dla Pracodawcy)

**GapRoll automatyzuje śledzenie:**

1. **Dashboard HR:**
   - Lista wniosków: Status | Data wpływu | Termin odpowiedzi | Dni pozostałe
   - Alert: 🔴 Termin <7 dni
   - Alert: 🟠 Termin <14 dni

2. **Auto-email przypomnienie:**
   - T-14 dni: "Wniosek Jana Kowalskiego wymaga odpowiedzi w ciągu 14 dni"
   - T-7 dni: "URGENT: Wniosek wymaga odpowiedzi w ciągu 7 dni"
   - T-0 dni: "OVERDUE: Termin minął — ryzyko skargi do PIP"

---

## Strategia Compliance

**Najlepsza praktyka:**
1. **Odpowiadaj szybko** (7-14 dni dla prostych wniosków)
2. **Komunikuj status** (jeśli potrzebujesz więcej czasu → powiedz od razu)
3. **Dokumentuj wszystko** (data wpływu, data odpowiedzi, uzasadnienie przedłużenia)
4. **Unikaj opóźnień** (kara finansowa < koszt dobrej reputacji)

**Przykład:**
- **Firma A:** Odpowiada w 10 dni → 0 skarg do PIP → reputacja "fair employer"
- **Firma B:** Odpowiada w 58 dni → 5 skarg rocznie → PIP audit → kara 50k PLN

---

## Powiązane Węzły

- [[00_INDEX_Art7]] — Główny węzeł Art. 7
- [[Procedura_Wniosku]] — Jak pracownik składa wniosek
- [[Kary_za_Opoznienie]] — Szczegóły sankcji (kiedy zostaną uchwalone w Polsce)

---

**Źródła:**
- Dyrektywa (UE) 2023/970, Art. 7 ust. 1, Motyw 23
- Dyrektywa (UE) 2023/970, Art. 18 (odwrócenie ciężaru dowodu)
- Kodeks Pracy, Art. 11^2 (zakaz dyskryminacji)
