# Zakres Danych do Ujawnienia (Art. 7)

---
description: "Szczegółowe określenie jakie dane pracodawca musi ujawnić w odpowiedzi na wniosek pracownika o informacje dotyczące wynagrodzeń."
related: ["00_INDEX_Art7", "Procedura_Wniosku", "RODO_Maskowanie"]
topic: "Zakres transparentności płacowej"
---

## Podstawa Prawna

**Art. 7 ust. 1 Dyrektywy UE 2023/970:**

Pracownik ma prawo do informacji o:
1. **Kryteriach określających wynagrodzenie**
2. **Średnim poziomie wynagrodzenia** (w podziale na płeć) dla pracowników wykonujących tę samą pracę lub pracę o równej wartości

---

## 1. Kryteria Określające Wynagrodzenie

### Co Należy Ujawnić?

**Pracodawca musi podać:**
- ✅ Zasady ustalania wynagrodzenia zasadniczego (skala płac, widełki, poziomy stanowisk)
- ✅ Kryteria przyznawania premii (KPI, wyniki pracy, staż)
- ✅ Kryteria przyznawania dodatków (funkcyjny, stażowy, lokalny)
- ✅ System wartościowania stanowisk (jeśli istnieje — np. EVG)

**Pracodawca NIE MUSI podać:**
- ❌ Indywidualnego wynagrodzenia konkretnych osób (RODO)
- ❌ Informacji handlowych (np. wysokość budżetu na wynagrodzenia)

---

### Przykłady Odpowiedzi

**Przykład 1: Kryteria ogólne**

```
Kryteria określające wynagrodzenie:
1. Wynagrodzenie zasadnicze: 
   - Poziom stanowiska (Junior/Mid/Senior)
   - Doświadczenie zawodowe (lata w branży)
   - Wykształcenie (licencjat/magister)

2. Premia kwartalna (15% wynagrodzenia):
   - Realizacja KPI osobistych (50% wagi)
   - Wyniki zespołu (30% wagi)
   - Ocena kompetencji miękkich przez managera (20% wagi)

3. Dodatki:
   - Dodatek stażowy: 1% za każdy rok pracy (max 10%)
   - Dodatek funkcyjny: 500 PLN dla Team Leadów
```

**Przykład 2: Kryteria z EVG (GapRoll)**

```
Kryteria określające wynagrodzenie:

Firma stosuje system wartościowania stanowisk EVG (Equal Value of Work) 
zgodnie z Art. 4 Dyrektywy UE 2023/970.

Stanowisko "Marketing Specialist" ma EVG Score: 65/100, obliczony na podstawie:
- Umiejętności (Skills): 18/25 (wymaga znajomości SEO, analytics, content marketing)
- Wysiłek (Effort): 16/25 (praca przy komputerze, standardowe godziny)
- Odpowiedzialność (Responsibility): 16/25 (zarządzanie kampaniami, budżet do 50k PLN/mies)
- Warunki (Conditions): 15/25 (biuro, standardowe warunki pracy)

Wynagrodzenie jest proporcjonalne do EVG Score (korelacja 0.85).
```

---

## 2. Średnie Wynagrodzenie (Podział na Płeć)

### Co Należy Ujawnić?

**Pracodawca musi podać:**
- ✅ **Średnią** lub **medianę** wynagrodzenia dla mężczyzn
- ✅ **Średnią** lub **medianę** wynagrodzenia dla kobiet
- ✅ Dla kategorii: "pracownicy wykonujący tę samą pracę lub pracę o równej wartości"

**Definicja kategorii:**
- **Ta sama praca:** Identyczne stanowisko (np. wszyscy "Accountant")
- **Równa wartość pracy:** Różne stanowiska, ale ten sam EVG score (±5%)

---

### Która Miara: Średnia czy Mediana?

**Zalecamy medianę** (bardziej odporna na wartości odstające):

**Przykład:**
- Wynagrodzenia mężczyzn: 5000, 5200, 5500, 6000, 15000 (outlier: CEO)
- Średnia: 7,340 PLN (zniekształcona przez CEO)
- Mediana: 5,500 PLN (reprezentatywna)

**Dyrektywa dopuszcza obie miary** — ale mediana jest bardziej fair.

---

### Maskowanie RODO (N<3)

**Zasada:**
Jeśli w grupie jest mniej niż 3 osoby jednej płci → dane są maskowane.

**Podstawa prawna:**
- RODO Art. 5 (minimalizacja danych)
- RODO Art. 6 (ochrona danych osobowych)
- Motyw 24 Dyrektywy UE 2023/970

**Przykłady maskowania:**

| Płeć | Liczba Osób | Mediana | Ujawnienie? |
|------|-------------|---------|-------------|
| Mężczyźni | 8 | 6,500 PLN | ✅ Ujawniamy (N≥3) |
| Kobiety | 2 | 6,200 PLN | ❌ Maskujemy: ***** (N<3) |

| Płeć | Liczba Osób | Mediana | Ujawnienie? |
|------|-------------|---------|-------------|
| Mężczyźni | 5 | 7,000 PLN | ✅ Ujawniamy (N≥3) |
| Kobiety | 4 | 6,800 PLN | ✅ Ujawniamy (N≥3) |

**Nota w odpowiedzi:**

```
Mediana wynagrodzenia (kobiety): Dane ukryte (RODO — mniej niż 3 osoby w kategorii)

Podstawa prawna: RODO (Rozporządzenie UE 2016/679), Art. 5 ust. 1 lit. c)
```

---

## 3. Składniki Wynagrodzenia (Co Wliczać?)

### Wliczane (Art. 4 Dyrektywy)

✅ **Wynagrodzenie zasadnicze** (gross salary)  
✅ **Premie regulaminowe** (contractual bonuses)  
✅ **Dodatki stałe** (funkcyjny, stażowy, lokalny)  
✅ **Nadgodziny** (jeśli regularnie występują)  
✅ **Ekwiwalent za urlop** (jeśli wypłacany)  

### NIE Wliczane

❌ **Premie uznaniowe** (discretionary bonuses — nieroszczeniowe)  
❌ **Jednorazowe nagrody** (bonuses awarded once)  
❌ **Zwroty kosztów** (travel, training reimbursements)  
❌ **Benefity niepieniężne** (car, insurance — chyba że można je przełożyć na PLN)  

---

### Przykład Kalkulacji

**Pracownik: Jan Kowalski, Marketing Specialist**

```
Wynagrodzenie zasadnicze:    5,000 PLN
Dodatek stażowy (5 lat):       250 PLN (5%)
Premia kwartalna (średnia):    750 PLN (15%)
Zwrot kosztów dojazdu:         300 PLN ❌ nie wliczamy

Wynagrodzenie do porównania: 5,000 + 250 + 750 = 6,000 PLN
```

**Kategoria: Marketing Specialist (EVG 60-70)**

| Płeć | N | Mediana | Status |
|------|---|---------|--------|
| Mężczyźni | 5 | 6,200 PLN | ✅ Ujawniane |
| Kobiety | 4 | 5,800 PLN | ✅ Ujawniane |

**Luka płacowa:** (6,200 - 5,800) / 6,200 = **6.5%**

---

## 4. Format Odpowiedzi

### Szablon Odpowiedzi (Minimalny)

```
Od: HR Department [Firma]
Do: [Imię Nazwisko Pracownika]
Data: [DD/MM/YYYY]

Temat: Odpowiedź na wniosek o informacje (Art. 7 Dyrektywy UE 2023/970)

Szanowny/-a Panie/Pani [Nazwisko],

W odpowiedzi na Pana/Pani wniosek z dnia [DD/MM/YYYY], przekazujemy następujące informacje:

1. Kryteria określające wynagrodzenie:
   [Opis kryteriów - patrz sekcja 1 powyżej]

2. Średnie wynagrodzenie dla kategorii "[Stanowisko]" (EVG Score: [X]):
   - Mediana wynagrodzenia (mężczyźni): [X] PLN brutto
   - Mediana wynagrodzenia (kobiety): [Y] PLN brutto LUB ***** (RODO)

3. Składniki wynagrodzenia uwzględnione w kalkulacji:
   - Wynagrodzenie zasadnicze
   - [Lista dodatków i premii]

Podstawa prawna: Art. 7 Dyrektywy UE 2023/970, RODO (Rozporządzenie UE 2016/679).

Z poważaniem,
[HR Manager]
[Podpis]
```

---

## 5. Częste Pytania (FAQ)

### Pytanie: "Czy muszę ujawnić wynagrodzenie CEO?"

**Nie.** Jeśli CEO jest jedyną osobą w swojej kategorii → dane są automatycznie maskowane (RODO). Pracownik otrzyma: "Dane ukryte (mniej niż 3 osoby w kategorii)."

### Pytanie: "Co jeśli pracownik poprosi o dane dla innej kategorii niż jego stanowisko?"

**Możesz odmówić.** Art. 7 daje prawo do informacji o **własnej kategorii** (ta sama praca lub równa wartość pracy). Pracownik Marketing Specialist nie ma prawa do danych o Senior Developers.

### Pytanie: "Czy mogę zaokrąglić kwoty?"

**Tak.** Możesz zaokrąglić do 100 PLN (np. 6,247 PLN → 6,200 PLN) aby dodatkowo utrudnić identyfikację konkretnych osób.

### Pytanie: "Co jeśli w firmie nie ma systemu EVG?"

**Musisz go wprowadzić.** Art. 4 Dyrektywy wymaga systemu wartościowania stanowisk. Jeśli nie masz → wdrażaj GapRoll EVG scoring (automatyczne).

---

## Powiązane Węzły

- [[00_INDEX_Art7]] — Główny węzeł Art. 7
- [[Procedura_Wniosku]] — Jak pracownik składa wniosek
- [[RODO_Maskowanie]] — Szczegóły maskowania danych (N<3)
- [[Skladniki_Wynagrodzenia]] — Co wliczać do wynagrodzenia (Art. 4)

---

**Źródła:**
- Dyrektywa (UE) 2023/970, Art. 4, Art. 7
- RODO (Rozporządzenie UE 2016/679), Art. 5, Art. 6
- Motyw 24 Dyrektywy UE 2023/970 (ochrona prywatności)
