# Procedura Składania Wniosku (Art. 7)

---
description: "Jak pracownik może złożyć wniosek o informacje dotyczące wynagrodzeń i jak pracodawca powinien odpowiedzieć."
related: ["00_INDEX_Art7", "Terminy_Odpowiedzi", "Zakres_Danych"]
topic: "Proces składania wniosku o transparentność płacową"
---

## Kto Może Złożyć Wniosek?

✅ **Każdy pracownik** zatrudniony w firmie 50+ osób  
✅ Pracownik zatrudniony na umowę o pracę, kontrakt lub umowę cywilnoprawną (jeśli Dyrektywa obejmuje)  
❌ Były pracownik (Dyrektywa dotyczy aktualnie zatrudnionych)

**Podstawa prawna:** Art. 7 ust. 1 Dyrektywy UE 2023/970

---

## Forma Wniosku

### Wymogi Formalne

**Wniosek musi być:**
- ✅ **Na piśmie** (email jest dopuszczalny)
- ✅ **Precyzyjny** — pracownik wskazuje, o jakie informacje prosi
- ❌ **Nie wymaga uzasadnienia** — pracownik nie musi wyjaśniać dlaczego pyta

**Przykładowy wniosek:**

```
Do: HR Manager [Nazwa firmy]
Od: [Imię Nazwisko], [Stanowisko]
Data: [DD/MM/YYYY]

Temat: Wniosek o informacje dotyczące wynagrodzeń (Art. 7 Dyrektywy UE 2023/970)

Szanowna Pani/Panie,

Na podstawie Art. 7 Dyrektywy UE 2023/970 proszę o udzielenie następujących informacji:

1. Kryteria określające moje wynagrodzenie (zasady ustalania wynagrodzenia zasadniczego, premii, dodatków).
2. Średnie wynagrodzenie (mediana) w podziale na płeć dla pracowników wykonujących pracę o równej wartości (stanowisko: [Twoje stanowisko]).

Z poważaniem,
[Podpis]
```

---

## Obowiązek Pracodawcy

**Pracodawca MUSI:**
1. ✅ Przyjąć wniosek (nie może odmówić)
2. ✅ Odpowiedzieć **w rozsądnym terminie** (max 2 miesiące) — [[Terminy_Odpowiedzi]]
3. ✅ Podać wymagane informacje zgodnie z [[Zakres_Danych]]
4. ✅ Zastosować ochronę RODO (maskowanie jeśli N<3)

**Pracodawca NIE MOŻE:**
- ❌ Zignorować wniosku
- ❌ Odmówić bez uzasadnienia prawnego
- ❌ Wymagać od pracownika uzasadnienia zapytania
- ❌ Dyskryminować pracownika za złożenie wniosku (Art. 13 Dyrektywy — zakaz odwetu)

---

## Proces Obsługi Wniosku (Pracodawca)

### Krok 1: Rejestracja Wniosku

- Pracownik HR rejestruje wniosek w systemie (data wpływu)
- Liczy się data otrzymania (email = data wysłania)
- **Termin liczony od dnia otrzymania**

### Krok 2: Identyfikacja Kategorii

**Pytanie:** Do jakiej kategorii należy pracownik?

**Metoda EVG (Equal Value of Work):**
- Firma używa systemu wartościowania stanowisk (np. GapRoll EVG)
- Znajduje wszystkich pracowników z tym samym EVG score (±5%)
- **To jest kategoria** do obliczenia średniej

**Przykład:**
- Wniosek od: Jan Kowalski, "Marketing Specialist", EVG Score: 65
- Kategoria: Wszyscy pracownicy z EVG 60-70 → znajdujemy: 8 mężczyzn, 6 kobiet

### Krok 3: Obliczenie Średnich

**Dane do obliczenia:**
- Wynagrodzenie zasadnicze + premie regulaminowe + dodatki stałe
- **NIE wliczamy:** Premie uznaniowe (nieroszczeniowe), jednorazowe nagrody, zwroty kosztów

**Oblicz:**
- Mediana wynagrodzenia mężczyzn: 6,500 PLN
- Mediana wynagrodzenia kobiet: 6,200 PLN

### Krok 4: Maskowanie RODO

**Zasada:** Jeśli w grupie jest mniej niż 3 osoby jednej płci → dane są maskowane.

**Przykład maskowania:**
- Mężczyźni: N=8 → Mediana: 6,500 PLN ✅ Ujawniamy
- Kobiety: N=2 → Mediana: ***** ❌ Maskujemy (RODO protection)

### Krok 5: Sporządzenie Odpowiedzi

**Odpowiedź zawiera:**
1. Kryteria określające wynagrodzenie (np. "Wynagrodzenie ustalane na podstawie doświadczenia, wykształcenia, wyników pracy mierzonych KPI")
2. Średnie wynagrodzenia w podziale na płeć (z maskowaniem RODO)

**Przykładowa odpowiedź:**

```
Od: HR Department [Nazwa firmy]
Do: Jan Kowalski
Data: [DD/MM/YYYY]

Temat: Odpowiedź na wniosek o informacje (Art. 7 Dyrektywy UE 2023/970)

Szanowny Panie Kowalski,

W odpowiedzi na Pana wniosek z dnia [DD/MM/YYYY], przekazujemy następujące informacje:

1. Kryteria wynagrodzenia:
   - Wynagrodzenie zasadnicze ustalane na podstawie: doświadczenia zawodowego, wykształcenia, wyników pracy (KPI kwartalne).
   - Premia regulaminowa: 15% wynagrodzenia zasadniczego (wypłata kwartalna).

2. Średnie wynagrodzenie dla kategorii "Marketing Specialist" (EVG Score 60-70):
   - Mediana wynagrodzenia (mężczyźni): 6,500 PLN brutto
   - Mediana wynagrodzenia (kobiety): Dane ukryte (RODO — mniej niż 3 osoby)

Podstawa prawna: Art. 7 Dyrektywy UE 2023/970, RODO (Rozporządzenie UE 2016/679).

Z poważaniem,
[HR Manager]
```

---

## Co Jeśli Pracownik Jest Niezadowolony z Odpowiedzi?

**Pracownik może:**
1. Złożyć skargę do Państwowej Inspekcji Pracy (PIP)
2. Wnieść sprawę do sądu pracy (art. 11^2 Kodeksu Pracy — zakaz dyskryminacji)
3. Zażądać [[Art_9_Joint_Assessment|wspólnej oceny wynagrodzeń]] (jeśli luka >5%)

**Kary za brak odpowiedzi:** Ustalane przez państwa członkowskie (Polska: do ustalenia przez Ministerstwo Rodziny i Polityki Społecznej).

---

## Powiązane Węzły

- [[00_INDEX_Art7]] — Główny węzeł Art. 7
- [[Terminy_Odpowiedzi]] — Szczegóły terminów
- [[Zakres_Danych]] — Co dokładnie ujawnić
- [[Art_9_Joint_Assessment]] — Procedura wspólnej oceny (jeśli luka >5%)

---

**Źródła:**
- Dyrektywa (UE) 2023/970, Art. 7, Art. 13
- RODO (Rozporządzenie UE 2016/679), Art. 5, Art. 6
- Kodeks Pracy, Art. 11^2 (zakaz dyskryminacji)
